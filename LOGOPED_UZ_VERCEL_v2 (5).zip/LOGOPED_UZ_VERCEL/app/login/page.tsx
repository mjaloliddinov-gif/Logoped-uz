import AuthPanel from '../components/AuthPanel';
export const metadata={title:'Kirish — LOGOPED.UZ',description:'LOGOPED.UZ shaxsiy kabinetiga xavfsiz kirish'};
export default function Login(){return <AuthPanel mode="login"/>}
