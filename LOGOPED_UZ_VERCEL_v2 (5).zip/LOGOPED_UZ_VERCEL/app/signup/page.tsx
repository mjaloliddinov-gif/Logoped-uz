import AuthPanel from '../components/AuthPanel';
export const metadata={title:'Ro‘yxatdan o‘tish — LOGOPED.UZ',description:'Logoped, ota-ona va o‘quvchi hisobini ro‘yxatdan o‘tkazish'};
export default function Signup(){return <AuthPanel mode="signup"/>}
